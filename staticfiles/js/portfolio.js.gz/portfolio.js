function readme() {
    document.getElementById('readme').classList.remove('d-none');
    document.getElementById('btn-readme').classList.add('d-none');
}